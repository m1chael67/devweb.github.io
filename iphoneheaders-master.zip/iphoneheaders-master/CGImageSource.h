#ifndef CGIMAGESOURCE_H_
#define CGIMAGESOURCE_H_
#define CGIMAGESOURCE_FALLBACK 1
typedef struct CGImageSource *CGImageSourceRef;
#endif
